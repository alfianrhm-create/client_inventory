<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Berita extends CI_Controller {

    public function _construct()
    {
        parent::_construct();
        $this->load->database();
        $this->load->model('Berita_model');
    }
}
public function index()
{
    $list_berita = $this->Berita_model->get_berita();

    $arr_view = array(
        'list_berita'=> $list_berita
    );

    $html_view = $this->load->view('daftar_berita', $arr_view, true);

    $data_json = array(
        'jumlah_berita' => $list_berita->num_rows(),
        'konten' => $html_view,
        'titel' => 'homepage',
    );
}