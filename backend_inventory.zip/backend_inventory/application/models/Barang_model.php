<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Model {
    public function get_barang()
    {
        $this->db->select('*');
        $this->db->from('barang');
        return $this->db->get();
    }

    public function get_barang($cari_nama = '', $cari_deskripsi = '', $cari_stok = '')
    {
        $this->db->select('*');
        $this->db->from('barang');
        $this->db->where('status_delete', 0);

        if ($cari_nama != '' && $cari_nama != null) {
            $this->db->like('deskripsi', $cari_deskripsi);
        }

        if ($cari_stok != '' && $cari_stok != null) {
            $this->db->where('stok <=', $cari_stok);
        }
        return $this->db->get();
    }
}